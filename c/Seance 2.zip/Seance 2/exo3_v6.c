/*
NOM      : UBAIDULLOEV
Prenom   : Rustam
Classe   : 3PSC
Groupe   : C1
Séance   : 2
Exercice : 3
Version  : 6
Date     : 05/02/2024
*/

#include"ma_biblio.h"

//-------------------------
// Programme  Principal
//-------------------------
int main() {

    exo3();
    return 0;
}
